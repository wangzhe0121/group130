import struct


def rotate_left(x, n) :
    return ((x << n) | (x >> (32 - n))) & 0xFFFFFFFF


    def P0(x) :
    return x ^ rotate_left(x, 9) ^ rotate_left(x, 17)


    def P1(x) :
    return x ^ rotate_left(x, 15) ^ rotate_left(x, 23)


    def FF(X, Y, Z, j) :
    if 0 <= j < 16 :
        return X ^ Y ^ Z
        elif 16 <= j < 64 :
        return (X & Y) | (X & Z) | (Y & Z)


        def GG(X, Y, Z, j) :
        if 0 <= j < 16 :
            return X ^ Y ^ Z
            elif 16 <= j < 64 :
            return (X & Y) | (~X & Z)


            def expand_message(message) :
            message_byte_length = len(message)
            append_bits = b'\x80'
            append_bits += b'\x00' * ((56 - message_byte_length - 1) % 64)
            append_bits += struct.pack('>Q', message_byte_length * 8)
            return message + append_bits


            def sm3(message) :
            iv = [
                0x7380166F, 0x4914B2B9, 0x172442D7, 0xDA8A0600,
                    0xA96F30BC, 0x163138AA, 0xE38DEE4D, 0xB0FB0E4E
            ]
            message = expand_message(message)
                    blocks = [message[i:i + 64] for i in range(0, len(message), 64)]

                    for block in blocks :
                w = [0] * 68
                    wv = [0] * 8
                    tv = [0] * 8

                    for i in range(16) :
                        w[i] = struct.unpack('>I', block[i * 4:(i + 1) * 4])[0]

                        for i in range(16, 68) :
                            w[i] = P1(w[i - 16] ^ w[i - 9] ^ rotate_left(w[i - 3], 15)) ^ rotate_left(w[i - 13], 7) ^ w[i - 6]

                            wv[:8] = iv[:]

                            for i in range(68) :
                                ss1 = rotate_left((rotate_left(wv[0], 12) + wv[4] + rotate_left(0x79CC4519, i)) & 0xFFFFFFFF, 7)
                                ss2 = ss1 ^ rotate_left(wv[0], 12)
                                tt1 = (FF(wv[0], wv[1], wv[2], i) + wv[3] + ss2 + w[i]) & 0xFFFFFFFF
                                tt2 = (GG(wv[4], wv[5], wv[6], i) + wv[7] + ss1 + w[i]) & 0xFFFFFFFF
                                tt3 = wv[3]
                                wv[3] = wv[2]
                                wv[2] = rotate_left(wv[1], 9)
                                wv[1] = wv[0]
                                wv[0] = tt1
                                wv[7] = wv[6]
                                wv[6] = rotate_left(wv[5], 19)
                                wv[5] = wv[4]
                                wv[4] = P0(tt2)

                                for i in range(8) :
                                    iv[i] ^= wv[i]

                                    return ''.join([f'{x:08x}' for x in iv])


                                    # ����
                                    message = "abc"
                                    hash_value = sm3(message.encode())
                                    print("Hash:", hash_value)